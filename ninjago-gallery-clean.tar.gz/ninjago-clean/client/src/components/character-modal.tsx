import { Character } from "@shared/schema";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

interface CharacterModalProps {
  character: Character;
  isOpen: boolean;
  onClose: () => void;
}

export default function CharacterModal({ character, isOpen, onClose }: CharacterModalProps) {
  const getElementColor = () => {
    switch (character.element.toLowerCase()) {
      case 'fire':
        return 'border-kai-red';
      case 'lightning':
        return 'border-jay-blue';
      case 'energy':
        return 'border-lloyd-green';
      case 'ice':
        return 'border-zane-ice';
      case 'earth':
        return 'border-earth-brown';
      case 'water':
        return 'border-cyan-500';
      case 'creation':
        return 'border-golden';
      case 'destruction':
        return 'border-purple-600';
      default:
        return 'border-gray-600';
    }
  };

  const getElementBgColor = () => {
    switch (character.element.toLowerCase()) {
      case 'fire':
        return 'bg-kai-red/20 border-kai-red';
      case 'lightning':
        return 'bg-jay-blue/20 border-jay-blue';
      case 'energy':
        return 'bg-lloyd-green/20 border-lloyd-green';
      case 'ice':
        return 'bg-zane-ice/20 border-zane-ice';
      case 'earth':
        return 'bg-earth-brown/20 border-earth-brown';
      case 'water':
        return 'bg-cyan-500/20 border-cyan-500';
      case 'creation':
        return 'bg-golden/20 border-golden';
      case 'destruction':
        return 'bg-purple-600/20 border-purple-600';
      default:
        return 'bg-gray-600/20 border-gray-600';
    }
  };

  const getElementTextColor = () => {
    switch (character.element.toLowerCase()) {
      case 'fire':
        return 'text-kai-red';
      case 'lightning':
        return 'text-jay-blue';
      case 'energy':
        return 'text-lloyd-green';
      case 'ice':
        return 'text-zane-ice';
      case 'earth':
        return 'text-earth-brown';
      case 'water':
        return 'text-cyan-500';
      case 'creation':
        return 'text-golden';
      case 'destruction':
        return 'text-purple-600';
      default:
        return 'text-gray-600';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent 
        className="bg-game-dark border-4 border-golden rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-8 modal-backdrop animate-pixel-fade"
        data-testid={`modal-character-${character.id}`}
      >
        <div className="absolute top-4 right-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="text-golden hover:text-white font-pixel text-lg"
            data-testid="button-close-modal"
          >
            <X className="h-6 w-6" />
          </Button>
        </div>

        <div className="text-center">
          <DialogTitle className="font-pixel text-3xl text-golden mb-4" data-testid={`text-modal-name-${character.id}`}>
            {character.name}
          </DialogTitle>
          <DialogDescription className="sr-only">
            Character details for {character.name}, the {character.element} ninja
          </DialogDescription>
          
          <div className="mb-6">
            <img
              src={character.imageUrl}
              alt={`${character.name} Portrait`}
              className={`w-full h-80 object-contain rounded-xl border-2 ${getElementColor()} bg-black/20`}
              data-testid={`img-modal-character-${character.id}`}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className={`${getElementBgColor()} rounded-lg p-4`}>
              <h4 className={`font-pixel ${getElementTextColor()} text-sm mb-2`} data-testid={`text-modal-element-label-${character.id}`}>
                ELEMENT
              </h4>
              <p className="font-cyber text-white" data-testid={`text-modal-element-${character.id}`}>
                {character.element}
              </p>
            </div>
            
            <div className="bg-golden/20 border-2 border-golden rounded-lg p-4">
              <h4 className="font-pixel text-golden text-sm mb-2" data-testid={`text-modal-weapon-label-${character.id}`}>
                WEAPON
              </h4>
              <p className="font-cyber text-white" data-testid={`text-modal-weapon-${character.id}`}>
                {character.weapon}
              </p>
            </div>
          </div>
          
          <div className="bg-game-deep rounded-lg p-6 border-2 border-gray-600 mb-6">
            <h4 className="font-pixel text-golden text-sm mb-3" data-testid={`text-modal-bio-label-${character.id}`}>
              BIOGRAPHY
            </h4>
            <p className="font-cyber text-gray-300 leading-relaxed" data-testid={`text-modal-bio-${character.id}`}>
              {character.description}
            </p>
          </div>

          <div className="bg-game-deep rounded-lg p-6 border-2 border-gray-600 mb-6">
            <h4 className="font-pixel text-golden text-sm mb-3" data-testid={`text-modal-power-label-${character.id}`}>
              POWER LEVEL
            </h4>
            <div className="flex items-center justify-center space-x-4">
              <div className="flex-1 bg-gray-700 rounded-full h-4">
                <div 
                  className={`h-4 rounded-full bg-gradient-to-r ${getElementColor().replace('border-', 'from-')} to-yellow-400`}
                  style={{ width: `${character.powerLevel}%` }}
                />
              </div>
              <span className="font-cyber text-white text-lg" data-testid={`text-modal-power-value-${character.id}`}>
                {character.powerLevel}/100
              </span>
            </div>
          </div>
          
          <div className="flex justify-center space-x-4">
            <Button 
              className={`px-6 py-3 bg-gradient-to-r ${getElementColor().replace('border-', 'from-')} to-opacity-80 border-2 border-white font-pixel text-sm hover:opacity-80 transition-opacity shadow-pixel text-white`}
              data-testid={`button-select-${character.id}`}
            >
              SELECT
            </Button>
            <Button 
              className="px-6 py-3 bg-golden border-2 border-white font-pixel text-sm text-game-dark hover:bg-yellow-400 transition-colors shadow-pixel"
              data-testid={`button-powers-${character.id}`}
            >
              POWERS
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
