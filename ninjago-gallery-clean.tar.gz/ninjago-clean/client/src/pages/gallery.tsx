import { useQuery } from "@tanstack/react-query";
import { Character } from "@shared/schema";
import CharacterCard from "@/components/character-card";
import CharacterModal from "@/components/character-modal";
import PowerStats from "@/components/power-stats";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";

export default function Gallery() {
  const [selectedCharacter, setSelectedCharacter] = useState<Character | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const { data: characters, isLoading, error } = useQuery<Character[]>({
    queryKey: ["/api/characters"],
  });

  const openCharacterModal = (character: Character) => {
    setSelectedCharacter(character);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedCharacter(null);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-golden mx-auto mb-4" />
          <p className="font-pixel text-golden text-lg">LOADING HEROES...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="font-pixel text-kai-red text-lg mb-4">ERROR LOADING HEROES</p>
          <p className="font-cyber text-gray-300">Please try again later</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div 
            style={{
              backgroundImage: `url('https://images.unsplash.com/photo-1550745165-9bc0b252726f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=400')`,
              backgroundSize: 'cover',
              backgroundPosition: 'center'
            }}
            className="w-full h-full"
          />
        </div>
        
        <nav className="relative z-10 container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-golden rounded-lg shadow-pixel flex items-center justify-center">
                <span className="text-game-dark font-pixel text-lg">⚡</span>
              </div>
              <h1 className="font-pixel text-golden text-xl animate-glow">NINJAGO</h1>
            </div>
            
            <div className="hidden md:flex space-x-6">
              <Button 
                data-testid="button-heroes"
                className="px-4 py-2 bg-kai-red border-2 border-white font-pixel text-sm hover:bg-fire-orange transition-colors shadow-pixel"
              >
                HEROES
              </Button>
              <Button 
                data-testid="button-powers"
                className="px-4 py-2 bg-jay-blue border-2 border-white font-pixel text-sm hover:bg-lightning-cyan hover:text-game-dark transition-colors shadow-pixel"
              >
                POWERS
              </Button>
              <Button 
                data-testid="button-quests"
                className="px-4 py-2 bg-lloyd-green border-2 border-white font-pixel text-sm hover:bg-green-400 transition-colors shadow-pixel"
              >
                QUESTS
              </Button>
            </div>
            
            <button 
              data-testid="button-mobile-menu"
              className="md:hidden p-2 bg-golden text-game-dark rounded font-pixel"
            >
              ☰
            </button>
          </div>
        </nav>
        
        <div className="relative z-10 text-center py-16 px-4">
          <h2 className="font-pixel text-4xl md:text-6xl mb-4 animate-glow text-golden">
            CHOOSE YOUR NINJA
          </h2>
          <p className="font-cyber text-lg md:text-xl max-w-2xl mx-auto text-gray-300">
            Discover the legendary heroes of Ninjago and their elemental powers in this retro-styled character gallery
          </p>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        {/* Characters Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8 mb-16">
          {characters?.map((character) => (
            <CharacterCard
              key={character.id}
              character={character}
              onClick={() => openCharacterModal(character)}
            />
          ))}
        </div>

        {/* Power Stats Section */}
        <PowerStats />
      </main>

      {/* Character Modal */}
      {selectedCharacter && (
        <CharacterModal
          character={selectedCharacter}
          isOpen={isModalOpen}
          onClose={closeModal}
        />
      )}

      {/* Footer */}
      <footer className="border-t-4 border-golden bg-game-deep/50 py-8 mt-16">
        <div className="container mx-auto px-4 text-center">
          <p className="font-pixel text-golden text-sm mb-4">MASTERS OF SPINJITZU</p>
          <p className="font-cyber text-gray-400 text-xs">
            Experience the power of the elements • Choose your destiny • Master your fears
          </p>
          
          <div className="mt-6 font-pixel text-xs text-gray-500">
            <p>GAME DESIGN: RETRO STUDIOS</p>
            <p>YEAR: 2024</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
