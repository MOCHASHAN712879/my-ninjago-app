import { type User, type InsertUser, type Character, type InsertCharacter } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllCharacters(): Promise<Character[]>;
  getCharacter(id: string): Promise<Character | undefined>;
  createCharacter(character: InsertCharacter): Promise<Character>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private characters: Map<string, Character>;

  constructor() {
    this.users = new Map();
    this.characters = new Map();
    this.initializeCharacters();
  }

  private initializeCharacters() {
    const ninjaCharacters: Character[] = [
      {
        id: "lloyd",
        name: "LLOYD",
        element: "Energy",
        weapon: "Golden Swords",
        description: "The legendary Green Ninja and leader of the team. Lloyd possesses the power of Energy and is destined to become the most powerful ninja in Ninjago. As the son of Lord Garmadon, he must balance the forces of good and evil within himself.",
        imageUrl: "/images/lloyd.jpg",
        color: "#44FF44",
        emoji: "🐲",
        powerLevel: 100
      },
      {
        id: "kai",
        name: "KAI",
        element: "Fire",
        weapon: "Fire Sword",
        description: "Master of Fire and the team's hothead. Kai is passionate, brave, and always ready to fight for what's right. His fiery spirit matches his elemental power, making him a formidable warrior in battle.",
        imageUrl: "/images/kai.jpg",
        color: "#FF4444",
        emoji: "🔥",
        powerLevel: 85
      },
      {
        id: "jay",
        name: "JAY",
        element: "Lightning",
        weapon: "Nunchucks",
        description: "The energetic Master of Lightning. Jay brings humor and electricity to every battle with his quick wit and faster reflexes. His positive attitude and lightning-fast speed make him invaluable to the team.",
        imageUrl: "/images/jay.jpg",
        color: "#4444FF",
        emoji: "⚡",
        powerLevel: 82
      },
      {
        id: "zane",
        name: "ZANE",
        element: "Ice",
        weapon: "Ice Shurikens",
        description: "The stoic Master of Ice and a Nindroid with advanced artificial intelligence. Zane's logical mind and ice-cold precision make him the team's strategist and a powerful ally in any situation.",
        imageUrl: "/images/zane.jpg",
        color: "#E6E6FA",
        emoji: "❄️",
        powerLevel: 88
      },
      {
        id: "cole",
        name: "COLE",
        element: "Earth",
        weapon: "Earth Hammer",
        description: "The strong and dependable Master of Earth. Cole's rock-solid determination and incredible strength make him the backbone of the ninja team. His connection to the earth gives him unmatched defensive capabilities.",
        imageUrl: "/images/cole.jpg",
        color: "#8B4513",
        emoji: "🗻",
        powerLevel: 86
      },
      {
        id: "nya",
        name: "NYA",
        element: "Water",
        weapon: "Water Katanas",
        description: "The determined Master of Water and Kai's sister. Nya is fierce, independent, and proves that she's just as capable as any ninja. Her mastery over water makes her a fluid and unpredictable fighter.",
        imageUrl: "/images/nya.jpg",
        color: "#00FFFF",
        emoji: "🌊",
        powerLevel: 84
      },
      {
        id: "wu",
        name: "SENSEI WU",
        element: "Creation",
        weapon: "Ancient Staff",
        description: "The wise master and teacher of the ninja team. Sensei Wu possesses ancient wisdom and the power of Creation. His guidance and knowledge of Spinjitzu have shaped countless warriors throughout the ages.",
        imageUrl: "/images/wu.jpg",
        color: "#FFD700",
        emoji: "🧙‍♂️",
        powerLevel: 95
      },
      {
        id: "garmadon",
        name: "GARMADON",
        element: "Destruction",
        weapon: "Dark Blades",
        description: "The complex Lord Garmadon, master of Destruction and Creation. Once evil, now reformed, he struggles with the balance between light and dark. His four-armed form and immense power make him a legendary figure.",
        imageUrl: "/images/garmadon.jpg",
        color: "#800080",
        emoji: "⚔️",
        powerLevel: 98
      }
    ];

    ninjaCharacters.forEach(character => {
      this.characters.set(character.id, character);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllCharacters(): Promise<Character[]> {
    return Array.from(this.characters.values());
  }

  async getCharacter(id: string): Promise<Character | undefined> {
    return this.characters.get(id);
  }

  async createCharacter(insertCharacter: InsertCharacter): Promise<Character> {
    const id = randomUUID();
    const character: Character = { ...insertCharacter, id };
    this.characters.set(id, character);
    return character;
  }
}

export const storage = new MemStorage();
