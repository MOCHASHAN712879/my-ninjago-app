# Ninjago Character Gallery

An interactive React.js gallery showcasing Ninjago characters with authentic images and retro gaming aesthetics.

## Features

- Interactive character cards with hover effects
- Detailed character modals with stats and descriptions  
- Retro gaming styling with pixel fonts and neon colors
- Express.js backend serving character data
- All 8 main characters: Lloyd, Kai, Jay, Cole, Zane, Nya, Sensei Wu, and Garmadon

## Getting Started

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm run dev
```

3. Open your browser to see the gallery in action!

## Tech Stack

- React 18 with TypeScript
- Express.js backend
- Tailwind CSS with custom gaming theme
- shadcn/ui components
- Authentic Ninjago character images

## Project Structure

- `client/` - React frontend
- `server/` - Express.js backend  
- `shared/` - Shared types and schemas
- `attached_assets/` - Character images